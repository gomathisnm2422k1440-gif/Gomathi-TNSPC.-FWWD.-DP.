// Example JavaScript functionality: Alert on clicking phone number

document.addEventListener("DOMContentLoaded", function() {

  const phoneLink = document.querySelector('a[href^="tel:"]');

  if (phoneLink) {

    phoneLink.addEventListener("click", function(e) {

      alert("Calling Gomathi S...");

    });

  }

});